package cn.make.module.combat;

import cn.make.util.skid.RebirthUtil;
import cn.make.util.skid.two.BlockUtil;
import dev.madcat.m3dc3t.M3dC3t;
import dev.madcat.m3dc3t.features.modules.Module;
import dev.madcat.m3dc3t.features.setting.Setting;
import net.minecraft.block.Block;
import net.minecraft.block.BlockDirectional;
import net.minecraft.block.BlockObsidian;
import net.minecraft.block.BlockPistonBase;
import net.minecraft.init.Blocks;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;

public class RebirthAnti extends Module {
   public static RebirthAnti INSTANCE;
   public final Setting<Boolean> rotate;
   public final Setting<Boolean> packet;
   public final Setting<Boolean> trap;
   private final Setting<Boolean> onlyBurrow;
   private final Setting<Boolean> whenDouble;
   private final Setting<Double> maxSelfSpeed;
   public final Setting<Boolean> helper;


   public RebirthAnti() {
      super("RebirthAnti", "Trap self when piston kick", Category.COMBAT);
      this.rotate = this.register(new Setting<>("Rotate", true));
      this.packet = this.register(new Setting<>("Packet", true));
      this.trap = this.register(new Setting<>("Trap", true));
      this.onlyBurrow = this.register(new Setting<>("OnlyBurrow", true, v -> trap.getValue()));
      this.whenDouble = this.register(new Setting<>("WhenDouble", true, v -> onlyBurrow.getValue()));
      this.maxSelfSpeed = this.register(new Setting<>("MaxSelfSpeed", 6.0, 1.0, 30.0));
      this.helper = this.register(new Setting<>("Helper", true));
      INSTANCE = this;
   }

   private Block getBlock(BlockPos var1) {
      return mc.world.getBlockState(var1).getBlock();
   }

   @Override
   public void onUpdate() {
      if (!fullNullCheck() && mc.player.onGround && !(M3dC3t.speedManager.getPlayerSpeed(mc.player) > this.maxSelfSpeed.getValue())) {
         this.block();
      }
   }

   private void placeBlock(BlockPos var1) {
      if (canPlace(var1)) {
         int var2 = mc.player.inventory.currentItem;
         if (RebirthUtil.findHotbarClass(BlockObsidian.class) != -1) {
            RebirthUtil.doSwap(RebirthUtil.findHotbarClass(BlockObsidian.class));
            BlockUtil.placeBlock(var1, EnumHand.MAIN_HAND, this.rotate.getValue(), this.packet.getValue());
            RebirthUtil.doSwap(var2);
         }
      }
   }

   public static boolean canPlace(BlockPos var0) {
      if (!RebirthUtil.canBlockFacing(var0)) {
         return false;
      } else if (!RebirthUtil.canReplace(var0)) {
         return false;
      } else {
         boolean var10000;
         if (!RebirthUtil.checkEntity(var0)) {
            var10000 = true;
            boolean var10001 = false;
         } else {
            var10000 = false;
         }

         return var10000;
      }
   }

   private void block() {
      BlockPos var1 = RebirthUtil.getPlayerPos();
      if (this.getBlock(var1.up(2)) != Blocks.OBSIDIAN && this.getBlock(var1.up(2)) != Blocks.BEDROCK) {
         int var2 = 0;
         if (this.whenDouble.getValue()) {
            for(EnumFacing var6 : EnumFacing.VALUES) {
               if (var6 != EnumFacing.DOWN) {
                  if (var6 == EnumFacing.UP) {
                     boolean var10000 = false;
                  } else if (this.getBlock(var1.offset(var6).up()) instanceof BlockPistonBase) {
                     if (((EnumFacing)mc.world.getBlockState(var1.offset(var6).up()).getValue(BlockDirectional.FACING)).getOpposite() != var6) {
                        boolean var15 = false;
                     } else {
                        ++var2;
                     }
                  }
               }

               boolean var16 = false;
            }
         }

         for(EnumFacing var14 : EnumFacing.VALUES) {
            if (var14 != EnumFacing.DOWN) {
               if (var14 == EnumFacing.UP) {
                  boolean var21 = false;
               } else if (this.getBlock(var1.offset(var14).up()) instanceof BlockPistonBase) {
                  if (((EnumFacing)mc.world.getBlockState(var1.offset(var14).up()).getValue(BlockDirectional.FACING)).getOpposite() != var14) {
                     boolean var20 = false;
                  } else {
                     this.placeBlock(var1.up().offset(var14, -1));
                     if (this.trap.getValue() && (this.getBlock(var1) != Blocks.AIR || !this.onlyBurrow.getValue() || var2 >= 2)) {
                        this.placeBlock(var1.up(2));
                        if (!RebirthUtil.canPlaceEnum(var1.up(2))) {
                           for(EnumFacing var10 : EnumFacing.VALUES) {
                              if (canPlace(var1.offset(var10).up(2))) {
                                 this.placeBlock(var1.offset(var10).up(2));
                                 boolean var18 = false;
                                 break;
                              }

                              boolean var17 = false;
                           }
                        }
                     }

                     if (!RebirthUtil.canPlaceEnum(var1.up().offset(var14, -1)) && this.helper.getValue()) {
                        if (RebirthUtil.canPlaceEnum(var1.offset(var14, -1))) {
                           this.placeBlock(var1.offset(var14, -1));
                           boolean var19 = false;
                        } else {
                           this.placeBlock(var1.offset(var14, -1).down());
                        }
                     }
                  }
               }
            }

            boolean var22 = false;
         }
      }
   }

}
